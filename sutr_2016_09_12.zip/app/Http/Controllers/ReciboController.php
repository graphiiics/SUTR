<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Recibo;
use App\Unidad;
use App\Paciente;
use App\Beneficio;
use Auth;

class ReciboController extends Controller
{
     public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(){
       
    	$recibos= Recibo::all();
        $pacientes=Paciente::where('unidad_id',Auth::user()->unidad_id)->orderBy('nombre', 'asc')->get();
    	return view('recibos/index',compact('recibos','pacientes'));
    }

    public function editarPaciente(Paciente $paciente,Request $request)
    {
    	if($paciente->update(['nombre'=>$request->input('nombre'),'direccion'=>$request->input('direccion'),'telefono'=>$request->input('telefono'),'celular'=>$request->input('celular'),'unidad'=>$request->input('unidad')])){
           }
        else{

        }
    	switch (Auth::user()->tipo) {
	    	case 1:
	    		return redirect('superAdmin/pacientes');
	    		break;
	    	case 2:
	    		return redirect('admin/pacientes');
	    		break;
	    	case 3:
	    		return redirect('gerente/pacientes');
	    		break;
    	
   		}
    }
    
    public function guardarRecibo(Request $request)
    {
    	$recibo= new Recibo($request->all());
        if($request->input('tipo_pago')=="Credito"){
            $recibo->estatus=2; // estatus del reicbo 1:Pagado 2:Credito 3:Conciliando 4: 
        }
    	$recibo->estatus=1;
        $recibo->user_id=Auth::user()->id;
        $recibo->fecha=date('Y-m-d');

    	if($recibo->save()){

        }
        else{

        }
            
    	switch (Auth::user()->tipo) {
	    	case 1:
	    		return redirect('superAdmin/pacientes');
	    		break;
	    	case 2:
	    		return redirect('admin/pacientes');
	    		break;
	    	case 3:
	    		return redirect('gerente/pacientes');
	    		break;
    	
   		}
   	}

    public function datosPaciente(Paciente $paciente)
    {  
        $algo=array();
        if($paciente->beneficios()->count()){
            $beneficio=Beneficio::find($paciente->beneficios->last()->id);
            $beneficio->concepto;
            return $beneficio;
        }else{
           
            return $algo;
        }       
       
    }

 }