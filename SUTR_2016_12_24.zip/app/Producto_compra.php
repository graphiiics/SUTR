<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Producto_compra extends Model
{
    //
}
