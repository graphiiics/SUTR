<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Producto_proveedor extends Model
{
    //
}
